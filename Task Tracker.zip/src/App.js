// src/App.js
import React, { useState, useEffect } from 'react';
import TaskForm from './components/TaskForm';
import TaskItem from './components/TaskItem';
import './styles/App.css';

const App = () => {
  const [user, setUser] = useState(localStorage.getItem('username') || null);
  const [username, setUsername] = useState(''); // ✅ FIXED: moved out of if-block
  const [tasks, setTasks] = useState(JSON.parse(localStorage.getItem('tasks')) || []);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [darkMode, setDarkMode] = useState(false);

  // Sync tasks to localStorage
  useEffect(() => {
    localStorage.setItem('tasks', JSON.stringify(tasks));
  }, [tasks]);

  // Sync dark mode class
  useEffect(() => {
    document.body.className = darkMode ? 'dark' : '';
  }, [darkMode]);

  // Add task
  const handleAddTask = (task) => {
    setTasks([task, ...tasks]);
  };

  // Delete task
  const handleDeleteTask = (id) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  // Update task
  const handleUpdateTask = (updatedTask) => {
    setTasks(tasks.map(task => (task.id === updatedTask.id ? updatedTask : task)));
  };

  // Filter + Search
  const filteredTasks = tasks.filter(task => {
    const matchesFilter =
      filter === 'completed' ? task.completed :
      filter === 'pending' ? !task.completed : true;
    const matchesSearch = task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          task.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  // Login logic
  const handleLogin = (username) => {
    localStorage.setItem('username', username);
    setUser(username);
  };

  const handleLogout = () => {
    if (window.confirm("Are you sure you want to logout?")) {
      localStorage.removeItem('username');
      setUser(null);
    }
  };

  // LOGIN SCREEN
  if (!user) {
    return (
      <div className="login-wrapper">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (username.trim()) handleLogin(username.trim());
          }}
          className="login-form"
        >
          <h2>Login</h2>
          <input
            type="text"
            placeholder="Enter your username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
          <button type="submit">Login</button>
        </form>
      </div>
    );
  }

  return (
    <div className="App">
      <div className="header">
        <h1>Welcome, {user}!</h1>
        <div className="header-actions">
          <button onClick={handleLogout}>Logout</button>
          <button onClick={() => setDarkMode(!darkMode)}>
            {darkMode ? '☀️ Light Mode' : '🌙 Dark Mode'}
          </button>
        </div>
      </div>

      <input
        type="text"
        placeholder="🔍 Search tasks..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="search-bar"
      />

      <TaskForm onAdd={handleAddTask} />

      <div className="filters">
        <button onClick={() => setFilter('all')}>
          All ({tasks.length})
        </button>
        <button onClick={() => setFilter('completed')}>
          Completed ({tasks.filter(t => t.completed).length})
        </button>
        <button onClick={() => setFilter('pending')}>
          Pending ({tasks.filter(t => !t.completed).length})
        </button>
      </div>

      <div className="task-list">
        {filteredTasks.length > 0 ? (
          filteredTasks.map(task => (
            <TaskItem
              key={task.id}
              task={task}
              onDelete={handleDeleteTask}
              onUpdate={handleUpdateTask}
            />
          ))
        ) : (
          <p style={{ marginTop: '20px' }}>No tasks found.</p>
        )}
      </div>
    </div>
  );
};

export default App;
