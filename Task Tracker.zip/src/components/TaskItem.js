// src/components/TaskItem.js
import React, { useState } from 'react';

const TaskItem = ({ task, onDelete, onUpdate }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editTitle, setEditTitle] = useState(task.title);
  const [editDesc, setEditDesc] = useState(task.description);
  const [editPriority, setEditPriority] = useState(task.priority);
  const [editDueDate, setEditDueDate] = useState(task.dueDate);
  const [editCategory, setEditCategory] = useState(task.category);

  const toggleComplete = () => {
    onUpdate({ ...task, completed: !task.completed });
  };

  const saveEdit = () => {
    if (!editTitle.trim()) return;

    onUpdate({
      ...task,
      title: editTitle,
      description: editDesc,
      priority: editPriority,
      dueDate: editDueDate,
      category: editCategory
    });

    setIsEditing(false);
  };

  const formattedDate = new Date(task.createdAt).toLocaleString();

  return (
    <div className={`task-card ${task.completed ? 'completed' : 'pending'}`}>

      {isEditing ? (
        <>
          <input value={editTitle} onChange={(e) => setEditTitle(e.target.value)} />
          <input value={editDesc} onChange={(e) => setEditDesc(e.target.value)} />
          <input
            type="date"
            value={editDueDate}
            onChange={(e) => setEditDueDate(e.target.value)}
          />
          <select
            value={editPriority}
            onChange={(e) => setEditPriority(e.target.value)}
          >
            <option value="Low">Low Priority</option>
            <option value="Medium">Medium Priority</option>
            <option value="High">High Priority</option>
          </select>
          <input
            value={editCategory}
            onChange={(e) => setEditCategory(e.target.value)}
            placeholder="Category / Tag"
          />
          <button onClick={saveEdit}>Save</button>
        </>
      ) : (
        <>
          <h3>{task.title}</h3>
          <p>{task.description}</p>
          <p><small>Created: {formattedDate}</small></p>
          {task.dueDate && <p><strong>Due:</strong> {task.dueDate}</p>}
          <p>
            <strong>Status:</strong>{' '}
            <span style={{ color: task.completed ? 'green' : 'red' }}>
              {task.completed ? 'Completed' : 'Pending'}
            </span>
          </p>
          <p><strong>Priority:</strong> {task.priority}</p>
          {task.category && <p><strong>Tag:</strong> {task.category}</p>}
        </>
      )}

      <div className="task-actions">
        <button onClick={toggleComplete}>
          {task.completed ? 'Mark Pending' : 'Mark Done'}
        </button>
        <button onClick={() => setIsEditing(!isEditing)}>
          {isEditing ? 'Cancel' : 'Edit'}
        </button>
        <button onClick={() => window.confirm('Delete task?') && onDelete(task.id)}>
          Delete
        </button>
      </div>
    </div>
  );
};

export default TaskItem;
